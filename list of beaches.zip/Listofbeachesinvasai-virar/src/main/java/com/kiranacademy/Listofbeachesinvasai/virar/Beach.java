package com.kiranacademy.Listofbeachesinvasai.virar;

public class Beach {
	private String nameofthecitywhichhavebeach;
	private int totalbeaches;
	private int totalClubsonbeaches;
	

  	public Beach(String nameofthecitywhichhavebeach, int totalbitches, int totalClubsonbeaches, int totalbeaches) {
		super();
		this.nameofthecitywhichhavebeach = nameofthecitywhichhavebeach;
		this.setTotalbeaches(totalbeaches);
		this.totalClubsonbeaches = totalClubsonbeaches;
	}
	


	public String getNameofthecitywhichhavebeach() {
		return nameofthecitywhichhavebeach;
	}

	public void setNameofthecitywhichhavebeach(String nameofthecitywhichhavebeach) {
		this.nameofthecitywhichhavebeach = nameofthecitywhichhavebeach;
	}

	public String toString() {
		String totalbitches = null;
		return "Beach [nameofthecitywhichhavebeach=" + nameofthecitywhichhavebeach + ", totalbitches=" + totalbitches
				+ ", totalClubsonbeaches=" + totalClubsonbeaches + "]";
	}



	public int getTotalbeaches() {
		return totalbeaches;
	}



	public void setTotalbeaches(int totalbeaches) {
		this.totalbeaches = totalbeaches;
	}

}


	