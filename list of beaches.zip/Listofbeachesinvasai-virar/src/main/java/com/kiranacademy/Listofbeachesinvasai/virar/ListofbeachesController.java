package com.kiranacademy.Listofbeachesinvasai.virar;

import java.util.ArrayList;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
public class ListofbeachesController {
  

	@RequestMapping("beaches")
	
	int noofbeachesinnsp() {
		return 5;	
	}
    @PostMapping("addbeachesInfo")
	public void addBeaches(Beach beaches) {
    	System.out.println("brideg info..."+beaches);
    	

	}
		

		
		
	@RequestMapping("BeachesInfo")
	ArrayList<Beach> fetchbeachesInfo() {
		ArrayList<Beach> albeacheslist=new ArrayList<Beach>();
		Beach beach1=new Beach("JhuBeach",4,20, 0);
		Beach beach2=new Beach("Marinelines",4,20, 0);
		Beach beach3=new Beach("Gorai",4,20, 0);
		Beach beach4=new Beach("Aksha",4,20, 0);
		Beach beach5=new Beach("Marve",4,20, 0);
		albeacheslist.add(beach1);
		albeacheslist.add(beach2);
		albeacheslist.add(beach3);
		albeacheslist.add(beach4);
		albeacheslist.add(beach5);
		return albeacheslist;

	} 
	
	@RequestMapping("nameofbeachesbycity/{cityname}")
	   ArrayList<String>noofbeachesinvirar( @PathVariable String cityname) {
		System.out.println("I am on beaches of vasai >> " +cityname);	
			
		
		ArrayList<String>nameofbeaches=new ArrayList<String>();
		if(cityname.equals("mumbai")) {
			nameofbeaches.add("kalamb beach");
			nameofbeaches.add("Rajodi beach");
			nameofbeaches.add("Arnala beach");
			nameofbeaches.add("Suruchi beach");
			nameofbeaches.add("Bhuigaon beach");
		}else {
		
		nameofbeaches.add("kalamb beach");
		nameofbeaches.add("Bhuigaon beach");
		nameofbeaches.add("Rajodi beach");
		nameofbeaches.add("Arnala beach");
		nameofbeaches.add("Suruchi beach");
		
	} 
		return nameofbeaches;
	}
	
}
