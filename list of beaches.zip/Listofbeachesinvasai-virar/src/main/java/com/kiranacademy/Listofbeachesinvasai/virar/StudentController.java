package com.kiranacademy.Listofbeachesinvasai.virar;

import java.util.ArrayList;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class StudentController {
	
	private ModelAndView mv;

	@GetMapping("beachesinfo")
	ModelAndView getBeaches( ){
		
		ArrayList<String>nameofbeaches=new ArrayList<String>();
		
			nameofbeaches.add("kalamb beach");
			nameofbeaches.add("Rajodi beach");
			nameofbeaches.add("Arnala beach");
			nameofbeaches.add("Suruchi beach");
			nameofbeaches.add("Bhuigaon beach");
		mv.setViewName("Shoallbeaches");
		mv.addObject("data",nameofbeaches);
	    return mv;
	    
		
		
	}

}
